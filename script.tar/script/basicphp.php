<?php
function add($a, $b){
$res=$a+$b;
print "added value $res <br/>";
}
add(3,2);
$ary= array(good,bad,ugly); #declared array
foreach($ary as $r){ #displaying array content 
echo $r."<br/>";
}
$hash=array(vehicle=>pollution,dance=>floor);#hash like variable in perl
print "keyvalue from the array $hash[vehicle]<br/>"; #displaying content 
$mary=array(array("mohan"=>"male",priyanka=>female),array(raja=>male,rani=>female)); #assosiate array like hash in perl
print $mary[1][raja]; #query for key which gives value as male
foreach($mary as $temp){
while(list($k, $v)=each($temp));
echo "$k....$v<br/>";
}
#object programming example
class mycar{
var $a=1; var $b=2; var $c=3;
}
$obj=new mycar();
echo $obj->a . "<br/>";
#object program using thish
class moh{
var $name=mohan;
function value($n){
$this->name=$n;
}
function disname(){
echo "display name ".$this->name;
}
}
$obj=new moh();
$obj->value(newmohan);
$obj->disname();
?>
