<?php
$dbhost = "mohan-desktop"; 
$dbuser = "root"; 
$dbpass = "test123"; 
$dbname = "mohandb"; 

//connect to mysql 
$db = mysql_connect($dbhost,$dbuser,$dbpass); 
//DB to connect
mysql_select_db("$dbname",$db);
print "hostinformation \t" .mysql_get_host_info($db)."\n";
#mysql_select_db("mohandb",$db);
$sqlquery="select * from users";
$result=mysql_query($sqlquery,$db) ;
while ($row=mysql_fetch_array($result)){
foreach ($row as $keys=>$values) {
print "$keys \t $values \n\n " ;
}
#print $row['id'] ;
}
mysql_close($db);
?>


