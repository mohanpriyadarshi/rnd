<?php
$a=2;
print time() ."<br/>";
$t=time();
echo date("m/d/y G:i:s");
?>
