<?php
class basec //this class used to display array in table format
{
public function  arrayf($arrayv) {
echo date("m/d/y G:i:s");
print "<table border=4>\n"; //table creation 
print"<th>Keys</th><th>Values</th>";
foreach ($arrayv as $keys1=>$values)
{
print "<tr><td>$keys1</td><td>$values</td></tr>\n"; //adding data to the rowa 
}
print "</table>"; //ending the table
}

########################################################################################
public function disjsonf($response)
{
$jsonResponse = json_decode($response);
print $jsonResponse->{'query'}->{'results'}->{'channel'}->{'item'}->{'description'};
}

########################################################################################
public function dispcurlf($url) { //to returns the raw content of curl call
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
return $response ;
curl_close($ch);
}
########################################################################################
public function dispcurlinfof($url) //returns status code, connect time ,redirect etc
{
$ch=curl_init($url);
curl_setopt($ch,CURLOPT_HEADER,false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
$info = curl_getinfo($ch);
return  $info ;
curl_close($ch);
}
}
?>
