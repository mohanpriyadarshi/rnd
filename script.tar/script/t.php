<?php
include  "base.php";
$obj=new dispcurlinfo() ;
$out=$obj->dispcurlinfof($url) ;
$
?>
