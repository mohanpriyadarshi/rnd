<?php
foreach($_POST as $keys=>$values)
{
print "$keys \t\t$values ";
print '<br>' ;
print $_SERVER['REMOTE_ADDR'] ;
}
?>
