<?php
include ("base.php") ;
error_reporting(E_ALL);
$yqlUrl = "http://query.yahooapis.com/v1/public/yql";
$yqlQuery = "select * from weather.forecast where location=91210";
$url = $yqlUrl . "?q=" . urlencode($yqlQuery) . "&format=json" . "&env=" . urlencode("store://datatables.org/alltableswithkeys");
$basecurl=new basec() ;
$output=$basecurl->dispcurlf($url) ;
#$infom=$basecurl->dispcurlinfof($url) ;
#$basecurl->arrayf($infom) ; //displaying keys and values 
#$basejson=new disjson() ;
$basecurl->disjsonf($output);
?>

