<?php
$con = mysql_connect("localhost","peter","abc123");
?>
