<?php
function msqli_connect()
{
echo "hello" ;
}
?>
